import 'presentation.dart';
import 'reference_context_menu.dart';
import 'historical_change_tree.dart';
import 'commit_details.dart';
import 'messages.dart';
import 'dart:async';
import 'dart:ui' show SemanticsRole;
import 'package:busystack_git/busystack_git.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'diff_view.dart';
import 'host.dart';
import 'session.dart';
import 'workflow_ui.dart';
import 'history_actions.dart';
import 'native_table.dart';
import 'context_menu_keys.dart';
import 'branch_views.dart';

final class GitLogView extends StatefulWidget {
  const GitLogView({
    super.key,
    required this.session,
    this.onCommitAction,
    this.onChooseCommit,
    this.initialCommit,
    this.inspector = false,
    this.preserveActionsWhenChoosing = false,
    this.onReview,
    this.path,
    this.active = true,
  });
  final GitSession session;
  final void Function(GitCommit commit, String action)? onCommitAction;

  /// Reuse the real paged, filterable Log as a read-only revision picker.
  final ValueChanged<GitCommit>? onChooseCommit;
  final GitOid? initialCommit;
  final bool inspector, preserveActionsWhenChoosing;
  final void Function(GitComparison comparison, List<GitComparison> files)?
  onReview;
  final RepoPath? path;
  final bool active;
  @override
  State<GitLogView> createState() => _GitLogViewState();
}

final class _GitLogViewState extends State<GitLogView> {
  final _message = TextEditingController(),
      _author = TextEditingController(),
      _path = TextEditingController(),
      _referenceSearch = TextEditingController();
  final _filterKeys = List.generate(3, (_) => GlobalKey());
  List<GitCommit> _commits = [];
  List<GitReference> _references = [];
  List<GitChange> _files = [];
  GitCommit? _selected;
  GitChange? _selectedFile;
  bool _expandedDiff = false;
  final _selectedIds = <GitOid>{};
  double _savedOffset(String key) {
    final value = widget.session.viewState[key];
    return value is num && value.isFinite && value >= 0 ? value.toDouble() : 0;
  }

  late final _tableScroll = ScrollController(
    initialScrollOffset: widget.preserveActionsWhenChoosing
        ? _savedOffset('selectorTableOffset')
        : 0,
  );
  final _tableKey = GlobalKey(debugLabel: 'Git Log table');
  final _previewKey = GlobalKey(debugLabel: 'Git Log comparison');
  FocusNode? _previewReturnFocus;
  late final _graphScroll = ScrollController(
    initialScrollOffset: widget.preserveActionsWhenChoosing
        ? _savedOffset('selectorGraphOffset')
        : 0,
  );
  double _graphOffset = 0;
  final _tableFocus = FocusNode(debugLabel: 'Git commits');
  final _contextMenuKeys = GitContextMenuKeys();
  int _selectionAnchor = 0;
  GitOid? _parent;
  GitOid? _inspectorOid;
  bool _choosing = false, _choiceSubmitted = false;
  bool get _selectionOnly =>
      widget.onChooseCommit != null && !widget.preserveActionsWhenChoosing;
  String? _reference, _anchor, _navigationReference;
  GitOid? _pendingNavigation;
  DateTime? _since, _until;
  GitException? _failure, _fileFailure;
  bool _filesLoading = false;
  bool _navigationOutsideFilters = false;
  bool _loading = true, _more = true, _branches = true, _details = true;
  int _generation = 0;
  int _interactionEpoch = 0, _dialogRequest = 0;
  ModalRoute<dynamic>? _presentationRoute, _selectorRoute;
  int _historyRevision = 0;
  int _selectionGeneration = 0;
  GitCancellation? _readCancellation;
  Timer? _referenceRefresh;
  bool _checkingReferences = false;
  GitOid? _observedHead;
  @override
  void initState() {
    super.initState();
    _path.text = widget.path?.utf8Path ?? '';
    _observedHead = widget.session.snapshot?.head;
    widget.session.addListener(_repositoryChanged);
    _graphScroll.addListener(_graphScrolled);
    if (widget.inspector) {
      final saved = widget.session.viewState['inspectorRevision'];
      _inspectorOid = saved is String
          ? GitOid(saved)
          : widget.session.snapshot?.head;
    }
    if (widget.onChooseCommit != null && widget.preserveActionsWhenChoosing) {
      final state = widget.session.viewState;
      _branches = widget.session.option('selectorBranches', true);
      _message.text = state['selectorMessage'] as String? ?? '';
      _author.text = state['selectorAuthor'] as String? ?? '';
      _path.text = state['selectorPath'] as String? ?? '';
      _reference = state['selectorReference'] as String?;
      if (_reference == '') _reference = null;
      _since = DateTime.tryParse(state['selectorSince'] as String? ?? '');
      _until = DateTime.tryParse(state['selectorUntil'] as String? ?? '');
      _pendingNavigation = widget.initialCommit;
    }
    unawaited(
      _load(
        preserveNavigation: widget.initialCommit != null,
        reveal: widget.initialCommit,
      ),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (!identical(route, _presentationRoute)) {
      _presentationRoute = route;
      _interactionEpoch++;
      _dialogRequest++;
    }
  }

  @override
  void didUpdateWidget(GitLogView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.session != widget.session ||
        oldWidget.path != widget.path ||
        oldWidget.active != widget.active) {
      if (oldWidget.session != widget.session || !widget.active)
        _dismissSelector();
      _interactionEpoch++;
      _dialogRequest++;
    }
    if (oldWidget.session != widget.session || oldWidget.path != widget.path) {
      oldWidget.session.removeListener(_repositoryChanged);
      widget.session.addListener(_repositoryChanged);
      _readCancellation?.cancel();
      _referenceRefresh?.cancel();
      _generation++;
      _commits = [];
      _references = [];
      _clearReview();
      _path.text = widget.path?.utf8Path ?? '';
      _observedHead = widget.session.snapshot?.head;
      if (widget.inspector) {
        final saved = widget.session.viewState['inspectorRevision'];
        _inspectorOid = saved is String
            ? GitOid(saved)
            : widget.session.snapshot?.head;
      }
      unawaited(_load());
    } else if (widget.active && !oldWidget.active) {
      _repositoryChanged();
    }
  }

  void _repositoryChanged() {
    if (!widget.active || _loading || widget.session.running) return;
    _referenceRefresh?.cancel();
    _referenceRefresh = Timer(
      const Duration(milliseconds: 450),
      () => unawaited(_checkReferences()),
    );
  }

  Future<void> _checkReferences() async {
    if (widget.inspector) {
      if (_selected == null &&
          _inspectorOid == null &&
          widget.session.snapshot?.head != null) {
        _inspectorOid = widget.session.snapshot!.head;
        await _loadInspector();
      } else {
        final session = widget.session, generation = _generation;
        try {
          final refs = await session.client.references(session.repository);
          if (mounted && session == widget.session && generation == _generation)
            setState(() => _references = refs);
        } on GitException catch (error) {
          if (mounted && session == widget.session && generation == _generation)
            setState(() => _failure = error);
        }
      }
      return;
    }
    if (_checkingReferences || !mounted || !widget.active) return;
    _checkingReferences = true;
    final session = widget.session;
    final generation = _generation;
    try {
      final refs = await session.client.references(session.repository);
      String identity(List<GitReference> values) => values
          .map((r) => '${r.name}:${r.oid.value}:${r.upstream}')
          .join('\n');
      if (mounted &&
          session == widget.session &&
          generation == _generation &&
          (identity(refs) != identity(_references) ||
              _observedHead != widget.session.snapshot?.head)) {
        _observedHead = widget.session.snapshot?.head;
        await _load(preserveNavigation: true);
      }
    } on Object catch (error) {
      if (mounted && session == widget.session && generation == _generation)
        setState(
          () => _failure = error is GitException
              ? error
              : GitException(
                  GitErrorCode.disconnected,
                  diagnostic: sanitizeGitDiagnostic('$error'),
                ),
        );
    } finally {
      _checkingReferences = false;
    }
  }

  void _graphScrolled() {
    // Responsive pane insertion can briefly reparent the old and new table
    // in one frame. A controller.offset read requires exactly one position.
    if (!mounted || _graphScroll.positions.length != 1) return;
    final offset = _graphScroll.positions.single.pixels;
    if (offset != _graphOffset) setState(() => _graphOffset = offset);
  }

  @override
  void dispose() {
    _dismissSelector();
    _interactionEpoch++;
    _dialogRequest++;
    _generation++;
    _selectionGeneration++;
    _readCancellation?.cancel();
    _referenceRefresh?.cancel();
    widget.session.removeListener(_repositoryChanged);
    if (widget.preserveActionsWhenChoosing) {
      if (_tableScroll.positions.length == 1)
        widget.session.setViewState(
          'selectorTableOffset',
          _tableScroll.positions.single.pixels,
        );
      if (_graphScroll.positions.length == 1)
        widget.session.setViewState(
          'selectorGraphOffset',
          _graphScroll.positions.single.pixels,
        );
      widget.session.setViewState('selectorBranches', _branches);
    }
    _tableScroll.dispose();
    _graphScroll.dispose();
    _contextMenuKeys.clear();
    _tableFocus.dispose();
    for (final c in [_message, _author, _path, _referenceSearch]) {
      c.dispose();
    }
    super.dispose();
  }

  HistoryFilter get _filter => _navigationReference != null
      ? HistoryFilter(reference: _navigationReference)
      : HistoryFilter(
          reference: _reference,
          author: _author.text,
          message: _message.text,
          since: _since,
          until: _until,
          path: _path.text.isEmpty ? null : RepoPath.text(_path.text),
          follow: widget.path != null,
        );
  bool get _hasFilters =>
      _reference != null ||
      _message.text.isNotEmpty ||
      _author.text.isNotEmpty ||
      _path.text.isNotEmpty ||
      _since != null ||
      _until != null;

  // A review is one dependent selection: commit, parent, files and preview.
  // Clear it atomically and retire requests/callbacks that still own its data.
  void _clearReview() {
    _selectionGeneration++;
    _selected = null;
    _parent = null;
    _selectedIds.clear();
    _files = [];
    _selectedFile = null;
    _expandedDiff = false;
    _filesLoading = false;
    _fileFailure = null;
  }

  Future<void> _load({
    bool append = false,
    bool preserveNavigation = false,
    GitOid? reveal,
  }) async {
    if (widget.inspector) return _loadInspector();
    if (widget.onChooseCommit != null && widget.preserveActionsWhenChoosing) {
      widget.session.setViewState('selectorMessage', _message.text);
      widget.session.setViewState('selectorAuthor', _author.text);
      widget.session.setViewState('selectorPath', _path.text);
      widget.session.setViewState('selectorReference', _reference ?? '');
      widget.session.setViewState(
        'selectorSince',
        _since?.toIso8601String() ?? '',
      );
      widget.session.setViewState(
        'selectorUntil',
        _until?.toIso8601String() ?? '',
      );
    }
    if (!append && !preserveNavigation) _navigationReference = null;
    final generation = ++_generation;
    final session = widget.session;
    // Retain the previous, accurately labelled review during loading, but no
    // pending file response may publish into a replacement history request.
    if (!append) _selectionGeneration++;
    setState(() {
      _loading = true;
      _failure = null;
      _navigationOutsideFilters = false;
      if (!preserveNavigation) _pendingNavigation = null;
    });
    _readCancellation?.cancel();
    final cancellation = _readCancellation = GitCancellation();
    try {
      final page = await session.client.history(
        session.repository,
        filter: _filter,
        offset: append ? _commits.length : 0,
        anchor: append ? _anchor : null,
        cancellation: cancellation,
      );
      final refs = append
          ? _references
          : await session.client.references(session.repository);
      if (!mounted || generation != _generation) return;
      setState(() {
        // The read generation changes before loading, while the old rows stay
        // visible. Native actions must advance with the applied row identities.
        _historyRevision++;
        _commits = append ? [..._commits, ...page.commits] : page.commits;
        _references = refs;
        _more = page.hasMore;
        _anchor = page.anchor;
        _loading = false;
        _selectedIds.retainAll(_commits.map((e) => e.oid));
        _selectionAnchor = _selectionAnchor.clamp(
          0,
          _commits.isEmpty ? 0 : _commits.length - 1,
        );
      });
      final retained = _commits
          .where((e) => e.oid == (reveal ?? _selected?.oid))
          .firstOrNull;
      if (reveal != null && retained == null) {
        setState(() {
          _clearReview();
          _navigationOutsideFilters = true;
          _failure = const GitException(
            GitErrorCode.invalidRequest,
            diagnostic: GitMessages
                .theRequestedRevisionIsOutsideTheCurrentFiltersResetFilters,
          );
        });
      } else if (reveal != null) {
        await _reveal(retained!);
      } else if (retained != null || _commits.isNotEmpty) {
        await _select(
          retained ?? _commits.first,
          parent: retained != null && retained.parents.contains(_parent)
              ? _parent
              : null,
        );
      } else {
        setState(() {
          _clearReview();
        });
      }
    } on Object catch (error) {
      if (mounted && generation == _generation)
        setState(() {
          _failure = error is GitException
              ? error
              : GitException(
                  GitErrorCode.disconnected,
                  diagnostic: sanitizeGitDiagnostic('$error'),
                );
          _loading = false;
          _clearReview();
        });
    }
  }

  Future<void> _select(GitCommit commit, {GitOid? parent}) async {
    final generation = ++_selectionGeneration;
    final comparisonParent = parent ?? commit.parents.firstOrNull;
    final previousFile =
        _selected?.oid == commit.oid && _parent == comparisonParent
        ? _selectedFile?.path
        : null;
    final retainExpanded =
        _expandedDiff &&
        _selected?.oid == commit.oid &&
        _parent == comparisonParent;
    final session = widget.session;
    setState(() {
      _selected = commit;
      _parent = comparisonParent;
      if (widget.inspector) {
        _inspectorOid = commit.oid;
        widget.session.setViewState('inspectorRevision', commit.oid.value);
        widget.session.setViewState(
          'inspectorParent',
          comparisonParent?.value ?? '',
        );
      }
      _files = [];
      _selectedFile = null;
      _expandedDiff = retainExpanded;
      _fileFailure = null;
      _filesLoading = true;
    });
    try {
      final files = await session.client.changedFiles(
        session.repository,
        commit.oid,
        parent: comparisonParent,
      );
      if (mounted && generation == _selectionGeneration)
        setState(() {
          _files = files;
          _selectedFile = previousFile == null
              ? null
              : files.where((file) => file.path == previousFile).firstOrNull;
          _filesLoading = false;
          if (_selectedFile == null) _expandedDiff = false;
        });
    } on Object catch (error) {
      if (mounted && generation == _selectionGeneration)
        setState(() {
          _selectedFile = null;
          _expandedDiff = false;
          _filesLoading = false;
          _fileFailure = error is GitException
              ? error
              : GitException(
                  GitErrorCode.disconnected,
                  diagnostic: sanitizeGitDiagnostic('$error'),
                );
        });
    }
  }

  @override
  Widget build(BuildContext context) => GitHostScope(
    host: widget.session.host,
    child: Builder(builder: _build),
  );
  double _textWidth(String text, [TextStyle? style]) {
    final painter = TextPainter(
      text: TextSpan(
        text: text,
        style: style ?? GitTheme.of(context).textTheme.bodyMedium,
      ),
      textDirection: Directionality.of(context),
      textScaler: MediaQuery.textScalerOf(context),
    )..layout();
    final width = painter.width;
    painter.dispose();
    return width;
  }

  void _resetFilters() {
    _dialogRequest++;
    _message.clear();
    _author.clear();
    _path.clear();
    _reference = null;
    _navigationReference = null;
    _pendingNavigation = null;
    _since = _until = null;
    unawaited(_load());
  }

  Future<void> _textFilter(
    TextEditingController controller,
    String title,
  ) async {
    if (!mounted || !widget.active || _presentationRoute?.isActive == false)
      return;
    final session = widget.session, epoch = _interactionEpoch;
    final request = ++_dialogRequest;
    final value = await gitTextInput(
      context,
      session,
      title,
      initial: controller.text,
    );
    if (!_ownsDialogRequest(session, epoch, request) || value == null) return;
    controller.text = value;
    await _load();
  }

  bool _ownsInteraction(GitSession session, int epoch) =>
      mounted &&
      widget.active &&
      (_presentationRoute?.isActive ?? true) &&
      widget.session == session &&
      epoch == _interactionEpoch;

  bool _ownsDialogRequest(GitSession session, int epoch, int request) =>
      _ownsInteraction(session, epoch) && request == _dialogRequest;

  final _referenceExpanded = <String, bool>{};
  final _referencePaneKey = GlobalKey();

  Widget _build(BuildContext context) => widget.inspector
      ? _inspector()
      : LayoutBuilder(
          builder: (context, bounds) {
            final host = widget.session.host;
            final tableMinimum = _textWidth('MMMMMMMMMMMMMMMMMMMMMMMM') + 40;
            final detailMinimum =
                _textWidth('MMMMMMMMMMMMMMMMMMMMMM') + host.spacing * 2;
            final showDetails =
                !widget.preserveActionsWhenChoosing &&
                _details &&
                bounds.maxWidth >=
                    (tableMinimum + detailMinimum + 6).clamp(
                      720.0,
                      double.infinity,
                    );
            final activeFilters = [
              _message.text,
              _author.text,
              _path.text,
              if (_since != null || _until != null) 'date',
            ].where((value) => value.isNotEmpty).length;
            Widget main = _commitTable();
            if (showDetails)
              main = GitSplitter(
                first: main,
                second: _detailPane(),
                initial: .64,
                minimum: tableMinimum,
                minimumSecond: detailMinimum,
                value: widget.session.split('logDetailsSplit', .64),
                onChanged: (v) =>
                    widget.session.setViewState('logDetailsSplit', v),
              );
            if (!widget.preserveActionsWhenChoosing && _selectedFile != null) {
              main = GitSplitter(
                axis: Axis.vertical,
                first: main,
                second: _expandedDiff
                    ? const SizedBox.expand()
                    : _diffPreview(),
                initial: .67,
                minimum: 220,
                minimumSecond: 200,
                value: widget.session.split('logPreviewSplit', .67),
                onChanged: (v) =>
                    widget.session.setViewState('logPreviewSplit', v),
              );
              main = Stack(
                fit: StackFit.expand,
                children: [
                  Offstage(
                    offstage: _expandedDiff,
                    child: ExcludeFocus(excluding: _expandedDiff, child: main),
                  ),
                  if (_expandedDiff) _diffPreview(expanded: true),
                ],
              );
            }
            final toolbar = Padding(
              padding: EdgeInsets.all(widget.session.host.spacing),
              child: Column(
                children: [
                  LayoutBuilder(
                    builder: (context, constraints) =>
                        _historyToolbar(constraints.maxWidth),
                  ),
                  if (activeFilters > 0)
                    Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Text(
                        [
                          if (_message.text.isNotEmpty)
                            '${gitString(context, GitMessages.message2)}: ${_message.text}',
                          if (_author.text.isNotEmpty)
                            '${gitString(context, GitMessages.author2)}: ${_author.text}',
                          if (_path.text.isNotEmpty)
                            '${gitString(context, GitMessages.path2)}: ${_path.text}',
                          if (_since != null || _until != null)
                            gitString(context, GitMessages.dateFilter),
                        ].join(' · '),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  if (_reference != null)
                    Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: GitFilterLabel(
                        label: Text(
                          gitString(
                            context,
                            GitMessages.referenceArg0,
                            values: {'arg0': _reference},
                          ),
                        ),
                        onDeleted: () {
                          _reference = null;
                          unawaited(_load());
                        },
                      ),
                    ),
                  if (_navigationReference != null)
                    GitFilterLabel(
                      label: Text(
                        gitString(
                          context,
                          GitMessages.referenceArg0,
                          values: {'arg0': _navigationReference},
                        ),
                      ),
                      onDeleted: () => unawaited(_load()),
                    ),
                ],
              ),
            );
            final history = Column(
              children: [
                if (_loading) const GitLoading(),
                if (_failure != null)
                  GitFailurePanel(
                    error: _failure!,
                    message: _navigationOutsideFilters
                        ? gitString(
                            context,
                            GitMessages
                                .theRequestedRevisionIsOutsideTheCurrentFiltersResetFilters,
                          )
                        : null,
                    onRefresh: () => unawaited(_load()),
                  ),
                if (_navigationOutsideFilters && _pendingNavigation != null)
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: GitButton(
                      onPressed: () {
                        final target = _pendingNavigation!;
                        _pendingNavigation = null;
                        _navigationReference = target.value;
                        unawaited(
                          _load(preserveNavigation: true, reveal: target),
                        );
                      },
                      child: const GitLabel(
                        GitMessages.revealRevisionWithoutFilters,
                      ),
                    ),
                  ),
                Expanded(child: main),
              ],
            );
            return GitHistoryLayout(
              sidebar: KeyedSubtree(
                key: _referencePaneKey,
                child: _branchPane(),
              ),
              main: history,
              toolbar: toolbar,
              sidebarVisible: _branches,
              onCompactReferences: () => unawaited(_showBranchFilter()),
              onToggle: () => setState(() => _branches = !_branches),
              sidebarFraction: widget.session.split('logBranchesSplit', .24),
              onResize: (value) => setState(
                () => widget.session.setViewState('logBranchesSplit', value),
              ),
              minimumHistoryWidth: tableMinimum,
              footer: widget.onChooseCommit == null
                  ? null
                  : Align(
                      alignment: AlignmentDirectional.centerEnd,
                      child: GitButton.primary(
                        compact: true,
                        onPressed:
                            _loading ||
                                _selected == null ||
                                _selectedIds.length > 1
                            ? null
                            : _confirmCandidate,
                        child: const GitLabel(GitMessages.selectThisCommit),
                      ),
                    ),
            );
          },
        );
  Future<void> _showBranchFilter() async {
    if (!mounted || !widget.active || _presentationRoute?.isActive == false)
      return;
    final session = widget.session, epoch = _interactionEpoch;
    final request = ++_dialogRequest, revision = _historyRevision;
    final references = List<GitReference>.unmodifiable(_references);
    final height = (MediaQuery.sizeOf(context).height * .6).clamp(180.0, 500.0);
    bool current() => _ownsDialogRequest(session, epoch, request);
    bool referenceCurrent(GitReference ref) =>
        current() &&
        revision == _historyRevision &&
        _references.any((r) => r.name == ref.name && r.oid == ref.oid);
    final choice = await session.host.present<_LogReferenceChoice>(
      context,
      GitMessages.filterBranchesAndTags,
      SizedBox(
        width: 420,
        height: height,
        child: _LogBranchFilterDialog(
          session: session,
          references: references,
          selected: _reference,
          initialSearch: _referenceSearch.text,
          chooseOnly: _selectionOnly,
          isCurrent: current,
          referenceCurrent: referenceCurrent,
          onFailure: (failure) {
            if (current()) setState(() => _failure = failure);
          },
          onSearchChanged: (value) {
            if (current()) setState(() => _referenceSearch.text = value);
          },
          refresh: () => current()
              ? _load(preserveNavigation: true)
              : Future<void>.value(),
        ),
      ),
      expanded: false,
    );
    if (!current() || choice == null) return;
    _reference = choice.reference;
    await _load();
  }

  /// One measured toolbar. Secondary commands use the host's native menu;
  /// reduced widths and enlarged/localized text never wrap unrelated commands.
  Widget _historyToolbar(double width) {
    final host = widget.session.host;
    final session = widget.session, epoch = _interactionEpoch;
    final spacing = host.spacing;
    final selectedIds = Set<GitOid>.of(_selectedIds);
    final historyRevision = _historyRevision;
    final selectedCommits = _commits
        .where((e) => selectedIds.contains(e.oid))
        .toList();
    bool ownsSelection() =>
        historyRevision == _historyRevision &&
        selectedIds.length == _selectedIds.length &&
        selectedIds.containsAll(_selectedIds);
    final fields = [
      (_message, GitMessages.message2, 16),
      (_author, GitMessages.author2, 12),
      (_path, GitMessages.path2, 14),
    ];
    final fieldWidths = [
      for (final field in fields)
        (_textWidth('M' * field.$3) + spacing * 2).clamp(
          _textWidth(gitString(context, field.$2)) + spacing * 4,
          double.infinity,
        ),
    ];
    final commandExtent = host.rowHeight(context) + spacing;
    final dateWidth =
        _textWidth(gitString(context, GitMessages.dateFilter)) + spacing * 4;
    final inline =
        width >=
        fieldWidths.reduce((a, b) => a + b) +
            dateWidth +
            commandExtent * 4 +
            spacing * 5;
    final filters = <GitMenuEntry>[
      // Keep the existing native filter editors available in overflow at narrow
      // widths/enlarged text, alongside the directly editable primary fields.
      if (!inline) ...[
        const GitMenuEntry('message', GitMessages.message),
        const GitMenuEntry('author', GitMessages.author),
        const GitMenuEntry('path', GitMessages.path),
      ],
      GitMenuEntry('reset', GitMessages.resetFilters, sectionStart: !inline),
      if (_navigationReference != null)
        const GitMenuEntry('restore', GitMessages.restoreHistoryFilters),
      const GitMenuEntry(
        'goto',
        GitMessages.goToCommitReference,
        sectionStart: true,
      ),
      const GitMenuEntry('head', GitMessages.backToHEAD),
      if (!_selectionOnly && _selectedIds.length > 1)
        GitMenuEntry(
          'cherry',
          gitString(
            context,
            GitMessages.reviewCherryPickArg0,
            values: {'arg0': _selectedIds.length},
          ),
          sectionStart: true,
          localize: false,
        ),
      if (_selectedIds.length == 2)
        const GitMenuEntry('compare', GitMessages.compareTwoSelectedRevisions),
    ];
    void selected(String value) {
      if (!_ownsInteraction(session, epoch)) return;
      switch (value) {
        case 'message':
          unawaited(_textFilter(_message, GitMessages.messageFilter));
        case 'author':
          unawaited(_textFilter(_author, GitMessages.authorFilter));
        case 'path':
          unawaited(_textFilter(_path, GitMessages.pathFilter));
        case 'date':
          unawaited(_dates());
        case 'reset':
          _resetFilters();
        case 'restore':
          unawaited(_load());
        case 'goto':
          unawaited(_goto());
        case 'head':
          unawaited(_navigate(GitMessages.head, reload: true));
        case 'cherry':
          if (!ownsSelection()) return;
          unawaited(
            GitWorkflowUi(context, session).present(
              GitMessages.orderedCherryPick,
              GitCherryPickView(
                session: session,
                commits: selectedCommits.reversed.toList(),
              ),
              expanded: true,
            ),
          );
        case 'compare':
          if (!ownsSelection()) return;
          final ids = selectedIds.toList();
          unawaited(
            GitHistoryActions(
              GitWorkflowUi(context, session),
            ).compare(ids.first, ids.last),
          );
      }
    }

    Widget field(int i) => KeyedSubtree(
      key: _filterKeys[i],
      child: GitTextField(
        key: ValueKey('git-history-filter-$i'),
        controller: fields[i].$1,
        decoration: GitFieldDecoration(
          labelText: gitString(context, fields[i].$2),
          isDense: true,
        ),
        onSubmitted: (_) => unawaited(_load()),
      ),
    );
    final commands = <Widget>[
      GitButton.standard(
        compact: true,
        onPressed: () => unawaited(_dates()),
        child: GitLabel(
          _since == null && _until == null
              ? GitMessages.date
              : GitMessages.dateFilter,
        ),
      ),
      SizedBox(width: spacing),
      GitMenuButton(
        role: GitMenuRole.viewActions,
        host: host,
        entries: filters,
        onSelected: selected,
        key: const ValueKey('git-history-actions'),
        tooltip: GitMessages.actions,
      ),
      SizedBox(width: spacing),
      GitIconButton(
        tooltip: GitMessages.refreshLog,
        onPressed: _loading ? null : () => unawaited(_load()),
        icon: const GitIcon(GitGlyph.refresh),
      ),
    ];
    Widget inputs() => LayoutBuilder(
      builder: (context, bounds) {
        final minWidth = fields
            .map((f) => _textWidth(gitString(context, f.$2)) + spacing * 4)
            .reduce((a, b) => a > b ? a : b);
        final columns = ((bounds.maxWidth + spacing) / (minWidth + spacing))
            .floor()
            .clamp(1, 3);
        final extent = (bounds.maxWidth - spacing * (columns - 1)) / columns;
        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: [
            for (var i = 0; i < fields.length; i++)
              SizedBox(width: extent, child: field(i)),
          ],
        );
      },
    );
    return Column(
      key: const ValueKey('git-history-toolbar'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (inline)
          Row(
            children: [
              for (var i = 0; i < fields.length; i++) ...[
                Expanded(child: field(i)),
                SizedBox(width: spacing),
              ],
              ...commands,
            ],
          )
        else ...[
          inputs(),
          SizedBox(height: spacing),
          Row(children: [const Spacer(), ...commands]),
        ],
      ],
    );
  }

  Widget _branchPane() {
    final session = widget.session, epoch = _interactionEpoch;
    return Builder(
      builder: (paneContext) => _logBranches(
        paneContext,
        search: _referenceSearch,
        expanded: _referenceExpanded,
        onToggle: (group) => setState(
          () =>
              _referenceExpanded[group] = !(_referenceExpanded[group] ?? true),
        ),
        references: _references,
        selected: _reference,
        onSearchChanged: () {
          if (_ownsInteraction(session, epoch)) setState(() {});
        },
        onChoose: (reference) {
          if (!_ownsInteraction(session, epoch)) return;
          _dialogRequest++;
          _reference = reference;
          unawaited(_load());
        },
        referenceBuilder: (ref, group) => _branchReference(ref, group),
      ),
    );
  }

  Widget _branchReference(GitReference ref, String group) {
    final session = widget.session, revision = _historyRevision;
    final epoch = _interactionEpoch;
    bool current() =>
        _ownsInteraction(session, epoch) &&
        revision == _historyRevision &&
        _references.any((r) => r.name == ref.name && r.oid == ref.oid);
    return _logBranchReference(
      context,
      session: session,
      references: _references,
      ref: ref,
      group: group,
      selected: _reference,
      chooseOnly: _selectionOnly,
      isCurrent: current,
      onChoose: (reference) {
        if (!current()) return;
        _dialogRequest++;
        _reference = reference;
        unawaited(_load());
      },
      onFailure: (failure) {
        if (current()) setState(() => _failure = failure);
      },
      refresh: () => _ownsInteraction(session, epoch)
          ? _load(preserveNavigation: true)
          : Future<void>.value(),
    );
  }

  String _referenceLabel(GitReference ref) {
    final kind = ref.name.startsWith('refs/tags/')
        ? GitMessages.tags
        : ref.name.startsWith('refs/remotes/')
        ? GitMessages.remote
        : GitMessages.local;
    return '${gitString(context, kind)}: ${ref.shortName}';
  }

  Widget _commitSubject(GitCommit commit, List<GitReference> references) =>
      GitTooltip(
        message: references.map(_referenceLabel).join(' · '),
        child: LayoutBuilder(
          builder: (context, bounds) => Row(
            children: [
              Expanded(
                child: Text(
                  commit.subject,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (references.isNotEmpty) ...[
                SizedBox(width: widget.session.host.spacing),
                ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: bounds.maxWidth * .32),
                  child: Text(
                    references.map(_referenceLabel).join(' · '),
                    style: GitTheme.of(context).textTheme.labelSmall,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ],
          ),
        ),
      );

  Widget _commitTable() {
    final graph = graphRows(_commits),
        rowHeight = widget.session.host.rowHeight(context);
    // A lane has the same horizontal coordinate in every row. Reserving the
    // widest graph column also keeps native table insets aligned with pixels.
    final graphContentWidth = graph.fold<double>(40, (width, row) {
      final needed = row.width * 14.0 + 14;
      return needed > width ? needed : width;
    });
    if (!_loading && _commits.isEmpty)
      return const Center(
        child: GitLabel(GitMessages.noCommitsMatchTheCurrentFilters),
      );
    return LayoutBuilder(
      builder: (context, bounds) {
        // The graph may have arbitrarily many real lanes. Pan its document
        // column with one shared viewport while subjects stay visible.
        final graphWidth = graphContentWidth.clamp(
          40.0,
          (bounds.maxWidth * .42).clamp(40.0, double.infinity),
        );
        final spacing = widget.session.host.spacing;
        final subjectMinimum = _textWidth('MMMMMMMMMMMMMMMM') + 40;
        final authorWidth = _textWidth('MMMMMMMMMMMM') + spacing * 2;
        final dateWidth =
            _textWidth('2000-12-31', GitTheme.of(context).textTheme.bodySmall) +
            spacing * 2;
        final idTextWidth = _textWidth(
          'ffffffffffff',
          GitTheme.of(context).textTheme.bodySmall,
        );
        final idTitleWidth = _textWidth(
          gitString(context, GitMessages.objectID),
        );
        final idWidth =
            (idTextWidth > idTitleWidth ? idTextWidth : idTitleWidth) +
            spacing * 2;
        final showId = bounds.maxWidth >= subjectMinimum + idWidth;
        final showAuthor =
            bounds.maxWidth >= subjectMinimum + idWidth + authorWidth;
        final showDate =
            bounds.maxWidth >=
            subjectMinimum + idWidth + authorWidth + dateWidth;
        final columns = [
          gitString(context, GitMessages.subjectReferences),
          if (showAuthor) gitString(context, GitMessages.author2),
          if (showDate) gitString(context, GitMessages.date2),
          if (showId) gitString(context, GitMessages.objectID),
        ];
        Widget columnCell(Widget child) => Padding(
          padding: EdgeInsetsDirectional.only(start: spacing),
          child: child,
        );
        return GitNativeTable(
          key: _tableKey,
          name: gitString(context, GitMessages.gitCommits),
          description: widget.session.repository.root,
          revision: (widget.session.repository.key, _historyRevision),
          active: widget.active && !_expandedDiff,
          busy: _loading,
          rowCount: _commits.length,
          rowHeight: rowHeight,
          columns: columns,
          headerInsets: [
            graphWidth,
            for (var i = 1; i < columns.length; i++) spacing,
          ],
          widths: [
            bounds.maxWidth -
                (showAuthor ? authorWidth : 0) -
                (showDate ? dateWidth : 0) -
                (showId ? idWidth : 0),
            if (showAuthor) authorWidth,
            if (showDate) dateWidth,
            if (showId) idWidth,
          ],
          rowAt: (index) {
            final commit = _commits[index];
            final refs = _references
                .where((r) => r.oid == commit.oid)
                .map(_referenceLabel)
                .join(', ');
            return GitNativeRow(
              id: commit.oid.value,
              textInsets: [
                graphWidth,
                for (var i = 1; i < columns.length; i++) spacing,
              ],
              cells: [
                '${refs.isEmpty ? '' : '[$refs]  '}${commit.subject}',
                if (showAuthor) commit.author,
                if (showDate) commit.date.toLocal().toString().substring(0, 10),
                if (showId) commit.oid.abbreviated,
              ],
              description:
                  '${commit.oid.value}; '
                  '${gitString(context, GitMessages.parents)}: '
                  '${commit.parents.map((p) => p.value).join(', ')}',
            );
          },
          selected: [
            for (var i = 0; i < _commits.length; i++)
              if (_selectedIds.contains(_commits[i].oid) ||
                  _selectedIds.isEmpty && _selected?.oid == _commits[i].oid)
                i,
          ],
          focusedRow: _commits.indexWhere((c) => c.oid == _selected?.oid),
          scroll: _tableScroll,
          focus: _tableFocus,
          onRequest: _nativeRequest,
          builder: (nativeReady) => Focus(
            focusNode: _tableFocus,
            onFocusChange: (focused) {
              if (!focused) _contextMenuKeys.clear();
            },
            onKeyEvent: (_, event) {
              final target = _selected, generation = _selectionGeneration;
              final revision = _historyRevision;
              if (_contextMenuKeys.handle(
                event,
                target == null
                    ? null
                    : () {
                        if (mounted &&
                            widget.active &&
                            _tableFocus.hasFocus &&
                            _historyRevision == revision &&
                            _selectionGeneration == generation &&
                            _selected?.oid == target.oid) {
                          unawaited(_menu(target));
                        }
                      },
              )) {
                return KeyEventResult.handled;
              }
              if (event is! KeyDownEvent || _commits.isEmpty)
                return KeyEventResult.ignored;
              if (event.logicalKey == LogicalKeyboardKey.enter &&
                  widget.onChooseCommit != null) {
                _confirmCandidate();
                return KeyEventResult.handled;
              }
              final index = _commits.indexWhere((e) => e.oid == _selected?.oid);
              if ({
                LogicalKeyboardKey.arrowUp,
                LogicalKeyboardKey.arrowDown,
              }.contains(event.logicalKey)) {
                final next =
                    (index +
                            (event.logicalKey == LogicalKeyboardKey.arrowDown
                                ? 1
                                : -1))
                        .clamp(0, _commits.length - 1);
                _choose(next);
                if (_tableScroll.hasClients)
                  _tableScroll.jumpTo(
                    (next * rowHeight).clamp(
                      0,
                      _tableScroll.position.maxScrollExtent,
                    ),
                  );
                return KeyEventResult.handled;
              }
              return KeyEventResult.ignored;
            },
            child: CustomScrollView(
              controller: _tableScroll,
              semanticChildCount: _commits.length,
              slivers: [
                SliverSemantics(
                  excludeSemantics: nativeReady,
                  sliver: SliverSemantics(
                    role: SemanticsRole.table,
                    container: true,
                    explicitChildNodes: true,
                    label: gitString(context, GitMessages.gitCommits),
                    sliver: SliverFixedExtentList(
                      itemExtent: rowHeight,
                      delegate: SliverChildBuilderDelegate(
                        (context, rowIndex) {
                          if (rowIndex == 0)
                            return Semantics(
                              role: SemanticsRole.row,
                              container: true,
                              explicitChildNodes: true,
                              child: Row(
                                children: [
                                  SizedBox(
                                    width: graphWidth,
                                    height: rowHeight,
                                    child: Semantics(
                                      role: SemanticsRole.columnHeader,
                                      container: true,
                                      label: gitString(
                                        context,
                                        GitMessages.graphLanes,
                                      ),
                                      child: GitScrollbar(
                                        controller: _graphScroll,
                                        thumbVisibility:
                                            graphContentWidth > graphWidth,
                                        child: SingleChildScrollView(
                                          key: const ValueKey(
                                            'git-graph-horizontal',
                                          ),
                                          controller: _graphScroll,
                                          scrollDirection: Axis.horizontal,
                                          child: SizedBox(
                                            width: graphContentWidth,
                                            height: rowHeight,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Semantics(
                                      role: SemanticsRole.columnHeader,
                                      child: const GitLabel(
                                        GitMessages.subjectReferences,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                  if (showAuthor)
                                    SizedBox(
                                      width: authorWidth,
                                      child: columnCell(
                                        Semantics(
                                          role: SemanticsRole.columnHeader,
                                          child: const GitLabel(
                                            GitMessages.author2,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ),
                                    ),
                                  if (showDate)
                                    SizedBox(
                                      width: dateWidth,
                                      child: columnCell(
                                        Semantics(
                                          role: SemanticsRole.columnHeader,
                                          child: const GitLabel(
                                            GitMessages.date2,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ),
                                    ),
                                  if (showId)
                                    SizedBox(
                                      width: idWidth,
                                      child: columnCell(
                                        Semantics(
                                          role: SemanticsRole.columnHeader,
                                          child: const GitLabel(
                                            GitMessages.objectID,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            );
                          final index = rowIndex - 1,
                              commit = _commits[rowIndex - 1];
                          final refs = _references
                              .where((e) => e.oid == commit.oid)
                              .toList();
                          final selected =
                              _selectedIds.contains(commit.oid) ||
                              _selectedIds.isEmpty &&
                                  _selected?.oid == commit.oid;
                          return Semantics(
                            role: SemanticsRole.row,
                            container: true,
                            explicitChildNodes: true,
                            selected: selected,
                            onTap: () => _choose(index),
                            child: _commitActivation(
                              index,
                              commit,
                              child: ColoredBox(
                                color: selected
                                    ? GitColors.of(context).selection
                                    : GitColors.of(context).transparent,
                                child: Row(
                                  children: [
                                    ExcludeSemantics(
                                      child: SizedBox(
                                        width: graphWidth,
                                        height: rowHeight,
                                        child: ClipRect(
                                          child: CustomPaint(
                                            key: ValueKey(
                                              'git-graph-${commit.oid.value}',
                                            ),
                                            painter: _GraphPainter(
                                              graph[index],
                                              GitColors.of(context).accent,
                                              offset: _graphOffset,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: Semantics(
                                        role: SemanticsRole.cell,
                                        container: true,
                                        label: gitString(
                                          context,
                                          GitMessages.arg0Parents,
                                          values: {
                                            'arg0': commit.parents.length,
                                          },
                                        ),
                                        child: _commitSubject(commit, refs),
                                      ),
                                    ),
                                    if (showAuthor)
                                      SizedBox(
                                        width: authorWidth,
                                        child: columnCell(
                                          Semantics(
                                            role: SemanticsRole.cell,
                                            child: Text(
                                              commit.author,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ),
                                      ),
                                    if (showDate)
                                      SizedBox(
                                        width: dateWidth,
                                        child: columnCell(
                                          Semantics(
                                            role: SemanticsRole.cell,
                                            child: Text(
                                              commit.date
                                                  .toLocal()
                                                  .toString()
                                                  .substring(0, 10),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: GitTheme.of(
                                                context,
                                              ).textTheme.bodySmall,
                                            ),
                                          ),
                                        ),
                                      ),
                                    if (showId)
                                      SizedBox(
                                        width: idWidth,
                                        child: columnCell(
                                          Semantics(
                                            role: SemanticsRole.cell,
                                            child: Text(
                                              commit.oid.abbreviated,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: GitTheme.of(
                                                context,
                                              ).textTheme.bodySmall,
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                        childCount: _commits.length + 1,
                        addSemanticIndexes: false,
                      ),
                    ),
                  ),
                ),
                if (_more)
                  SliverToBoxAdapter(
                    child: GitButton(
                      onPressed: _loading
                          ? null
                          : () => unawaited(_load(append: true)),
                      child: const GitLabel(GitMessages.loadMoreCommits),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _nativeRequest(GitNativeTableRequest request) {
    final index = request.row;
    switch (request.action) {
      case 'clearSelection':
        setState(() {
          _selectedIds.clear();
          _selected = null;
          _files = [];
          _selectionGeneration++;
        });
      case 'selectAll':
        setState(() => _selectedIds.addAll(_commits.map((c) => c.oid)));
      case 'select' || 'focus':
        _choose(index, keyboardModifiers: false);
        _scrollToNativeRow(index);
      case 'scroll':
        _scrollToNativeRow(index);
      case 'context':
        _choose(index, keyboardModifiers: false);
        unawaited(_menu(_commits[index]));
      case 'addSelection':
        setState(() {
          if (_selectedIds.isEmpty && _selected != null) {
            _selectedIds.add(_selected!.oid);
          }
          _selectedIds.add(_commits[index].oid);
        });
      case 'removeSelection':
        setState(() {
          _selectedIds.remove(_commits[index].oid);
          if (_selected?.oid == _commits[index].oid) {
            _selected = null;
            _files = [];
            _selectionGeneration++;
          }
        });
    }
  }

  void _scrollToNativeRow(int index) {
    if (_tableScroll.hasClients) {
      final row = widget.session.host.rowHeight(context);
      final start = (index + 1) * row, end = start + row;
      final position = _tableScroll.position;
      if (start < position.pixels ||
          end > position.pixels + position.viewportDimension) {
        _tableScroll.jumpTo(start.clamp(0, position.maxScrollExtent));
      }
    }
  }

  Widget _commitActivation(
    int index,
    GitCommit commit, {
    required Widget child,
  }) => Listener(
    onPointerDown: widget.onChooseCommit == null
        ? null
        : (event) {
            if (event.buttons == 1) _choose(index);
          },
    child: GestureDetector(
      behavior: HitTestBehavior.opaque,
      excludeFromSemantics: true,
      onTap: widget.onChooseCommit == null ? () => _choose(index) : null,
      onDoubleTap: widget.onChooseCommit == null
          ? null
          : () {
              _choose(index, keyboardModifiers: false);
              _confirmCandidate();
            },
      onSecondaryTapUp: (details) =>
          unawaited(_menu(commit, position: details.globalPosition)),
      child: child,
    ),
  );

  void _choose(int index, {bool keyboardModifiers = true}) {
    final commit = _commits[index];
    _tableFocus.requestFocus();
    setState(() {
      if (keyboardModifiers && HardwareKeyboard.instance.isShiftPressed) {
        _selectedIds.clear();
        for (
          var i = _selectionAnchor < index ? _selectionAnchor : index;
          i <= (_selectionAnchor > index ? _selectionAnchor : index);
          i++
        ) {
          _selectedIds.add(_commits[i].oid);
        }
      } else if (keyboardModifiers &&
          HardwareKeyboard.instance.isControlPressed) {
        if (!_selectedIds.add(commit.oid)) _selectedIds.remove(commit.oid);
      } else {
        _selectedIds
          ..clear()
          ..add(commit.oid);
        _selectionAnchor = index;
      }
    });
    unawaited(_select(commit));
  }

  GitComparison _comparison(GitCommit commit, GitChange file, GitOid? parent) =>
      GitComparison(
        file.path,
        parent == null
            ? const ContentVersion.absent()
            : ContentVersion(ContentKind.commit, revision: parent),
        ContentVersion(ContentKind.commit, revision: commit.oid),
        leftPath: file.originalPath,
      );

  void _confirmCandidate() {
    if (!mounted ||
        _loading ||
        _selected == null ||
        _selectedIds.length > 1 ||
        _choiceSubmitted ||
        widget.onChooseCommit == null ||
        _presentationRoute?.isCurrent != true)
      return;
    _choiceSubmitted = true;
    widget.onChooseCommit!(_selected!);
  }

  Future<void> _loadInspector({GitOid? target}) async {
    final generation = ++_generation, session = widget.session;
    _readCancellation?.cancel();
    final cancellation = _readCancellation = GitCancellation();
    final oid = target ?? _inspectorOid;
    setState(() {
      _loading = true;
      _failure = null;
    });
    try {
      if (oid == null) {
        if (mounted && generation == _generation)
          setState(() {
            _clearReview();
            _loading = false;
          });
        return;
      }
      final page = await session.client.history(
        session.repository,
        filter: HistoryFilter(reference: oid.value),
        cancellation: cancellation,
        limit: 1,
      );
      final refs = await session.client.references(session.repository);
      if (!mounted || generation != _generation || session != widget.session)
        return;
      final commit = page.commits
          .where((value) => value.oid == oid)
          .firstOrNull;
      if (commit == null) throw const GitException(GitErrorCode.missingContent);
      setState(() {
        _commits = [commit];
        _references = refs;
        _loading = false;
      });
      final savedParent = session.viewState['inspectorParent'];
      await _select(
        commit,
        parent: commit.parents
            .where((oid) => oid.value == savedParent)
            .firstOrNull,
      );
      final selectedFile = session.viewState['inspectorFile'];
      if (mounted && generation == _generation)
        setState(() {
          _selectedFile = _files
              .where((file) => file.path.toJson() == selectedFile)
              .firstOrNull;
        });
    } on Object catch (error) {
      if (mounted && generation == _generation && session == widget.session)
        setState(() {
          _loading = false;
          _failure = error is GitException
              ? error
              : GitException(
                  GitErrorCode.disconnected,
                  diagnostic: sanitizeGitDiagnostic('$error'),
                );
        });
    }
  }

  Future<void> _chooseInspectorCommit() async {
    if (_choosing || !mounted || !widget.active) return;
    final session = widget.session, epoch = _interactionEpoch;
    setState(() => _choosing = true);
    try {
      final commit = await session.host.present<GitCommit>(
        context,
        GitMessages.log,
        GitDialogBody(
          child: Builder(
            builder: (dialogContext) {
              _selectorRoute = ModalRoute.of(dialogContext);
              return GitLogView(
                session: session,
                initialCommit: _selected?.oid ?? _inspectorOid,
                preserveActionsWhenChoosing: true,
                onChooseCommit: (commit) =>
                    gitCompleteSurface(dialogContext, commit),
              );
            },
          ),
        ),
        expanded: true,
      );
      if (!_ownsInteraction(session, epoch) || commit == null) return;
      // A confirmed candidate owns both history and dependent file reads.
      // Retire an initial/refresh read that may still resolve the previous OID.
      _generation++;
      _readCancellation?.cancel();
      session.setViewState('inspectorFile', '');
      setState(() {
        _loading = false;
        _failure = null;
        _commits = [commit];
      });
      await _select(commit);
    } finally {
      _selectorRoute = null;
      if (mounted && session == widget.session)
        setState(() => _choosing = false);
    }
  }

  void _dismissSelector() {
    final route = _selectorRoute;
    _selectorRoute = null;
    if (route == null) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (route.isActive && !route.isFirst) route.navigator?.removeRoute(route);
    });
  }

  Widget _inspector() => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      GitLogHeader(
        key: const ValueKey('git-commit-header'),
        subject: GitActionRow(
          key: const ValueKey('git-selected-commit'),
          dense: true,
          contentPadding: EdgeInsets.zero,
          leading: const GitIcon(GitGlyph.history, size: 16),
          title: GitTooltip(
            message:
                _selected?.subject ??
                gitString(context, GitMessages.selectACommit),
            child: Text(
              _selected?.subject ??
                  gitString(context, GitMessages.selectACommit),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        choose: GitIconButton(
          key: const ValueKey('git-select-another-commit'),
          tooltip: gitString(
            context,
            GitMessages.selectAnotherCommit,
          ).replaceFirst(RegExp(r'…$'), ''),
          onPressed: _choosing
              ? null
              : () => unawaited(_chooseInspectorCommit()),
          icon: const GitIcon(GitGlyph.history),
        ),
        actions: Builder(
          builder: (anchor) => GitIconButton.actions(
            key: const ValueKey('git-commit-actions'),
            tooltip: GitMessages.actions,
            onPressed: _choosing
                ? null
                : () {
                    final box = anchor.findRenderObject() as RenderBox;
                    unawaited(
                      _menu(
                        _selected,
                        position: box.localToGlobal(
                          Offset(
                            Directionality.of(anchor) == TextDirection.rtl
                                ? box.size.width
                                : 0,
                            box.size.height,
                          ),
                        ),
                      ),
                    );
                  },
          ),
        ),
      ),
      if (_loading) const GitLoading(),
      if (_failure != null)
        Flexible(
          child: SingleChildScrollView(
            child: GitFailurePanel(
              error: _failure!,
              onRefresh: () => unawaited(_loadInspector()),
            ),
          ),
        ),
      if (_selected != null && _failure == null)
        Expanded(child: _detailPane())
      else if (!_loading && _failure == null)
        const Expanded(
          child: Center(child: GitLabel(GitMessages.noCommitsYet)),
        ),
    ],
  );

  Widget _changedFilesPane(GitCommit commit) {
    final generation = _selectionGeneration;
    final parent = _parent;
    bool current() =>
        mounted &&
        _selectionGeneration == generation &&
        _selected?.oid == commit.oid &&
        _parent == parent;
    if (_filesLoading) {
      return Center(
        child: GitLoading.spinner(
          semanticsLabel: gitString(context, GitMessages.loadingChangedFiles),
        ),
      );
    }
    if (_fileFailure case final error?) {
      return SingleChildScrollView(
        child: GitFailurePanel(
          error: error,
          onRefresh: () {
            if (current()) unawaited(_select(commit, parent: parent));
          },
        ),
      );
    }
    if (_files.isEmpty) {
      return Center(
        child: Semantics(
          container: true,
          liveRegion: true,
          child: const GitLabel(GitMessages.noChangedFiles),
        ),
      );
    }
    if (widget.inspector) {
      final session = widget.session;
      final comparisons = List<GitComparison>.unmodifiable(
        _files.map((change) => _comparison(commit, change, parent)),
      );
      void highlight(GitChange file) {
        if (!current()) return;
        setState(() => _selectedFile = file);
        session.setViewState('inspectorFile', file.path.toJson());
      }

      return GitHistoricalChangeTree(
        key: ValueKey(
          'git-historical-tree:${session.repository.presentationKey}',
        ),
        session: session,
        files: _files,
        selected: _selectedFile?.path,
        onHighlight: highlight,
        onActivate: (file) {
          if (!current()) return;
          highlight(file);
          widget.onReview?.call(_comparison(commit, file, parent), comparisons);
        },
        onAction: (file, action) async {
          if (!current() ||
              !widget.active ||
              _presentationRoute?.isCurrent == false)
            return;
          switch (action) {
            case 'review':
              highlight(file);
              widget.onReview?.call(
                _comparison(commit, file, parent),
                comparisons,
              );
            case 'history':
              await session.host.present<void>(
                context,
                GitMessages.fileHistoryAndBlame,
                GitFileHistoryView(
                  session: session,
                  path: file.path,
                  revision: commit.oid,
                ),
                expanded: true,
              );
            case 'snapshot':
              await session.host.present<void>(
                context,
                GitMessages.openSnapshot,
                GitSnapshotView(session: session, revision: commit.oid),
                expanded: true,
              );
          }
        },
      );
    }
    return ListView.builder(
      key: PageStorageKey(
        'git-inspector-files:${widget.session.repository.presentationKey}',
      ),
      itemCount: _files.length,
      itemBuilder: (context, i) {
        final file = _files[i];
        final session = widget.session;
        final comparisons = List<GitComparison>.unmodifiable(
          _files.map((change) => _comparison(commit, change, parent)),
        );
        void activate() {
          if (!current()) return;
          setState(() => _selectedFile = file);
          if (widget.inspector) {
            session.setViewState('inspectorFile', file.path.toJson());
            widget.onReview?.call(
              _comparison(commit, file, parent),
              comparisons,
            );
          }
        }

        Future<void> action(String value) async {
          if (!current() ||
              !widget.active ||
              _presentationRoute?.isCurrent == false)
            return;
          if (value == 'review') activate();
          if (value == 'history')
            await session.host.present<void>(
              context,
              GitMessages.fileHistoryAndBlame,
              GitFileHistoryView(
                session: session,
                path: file.path,
                revision: commit.oid,
              ),
              expanded: true,
            );
          if (value == 'snapshot')
            await session.host.present<void>(
              context,
              GitMessages.openSnapshot,
              GitSnapshotView(session: session, revision: commit.oid),
              expanded: true,
            );
        }

        const entries = [
          GitMenuEntry('review', GitMessages.reviewDifference),
          GitMenuEntry('history', GitMessages.fileHistoryAndBlame),
          GitMenuEntry('snapshot', GitMessages.openSnapshot),
        ];
        Future<void> menu({Offset? position}) async {
          if (!current() ||
              !widget.active ||
              _presentationRoute?.isCurrent == false)
            return;
          final value = await session.host.menu(
            context,
            file.path.display,
            entries,
            position: position,
            localizeTitle: false,
          );
          if (value != null) await action(value);
        }

        return Focus(
          onFocusChange: (focused) {
            if (!focused) _contextMenuKeys.clear();
          },
          onKeyEvent: (_, event) =>
              _contextMenuKeys.handle(event, () => unawaited(menu()))
              ? KeyEventResult.handled
              : KeyEventResult.ignored,
          child: GestureDetector(
            onSecondaryTapUp: (details) =>
                unawaited(menu(position: details.globalPosition)),
            child: GitActionRow(
              dense: true,
              leading: Text(file.index),
              title: Text(
                file.path.basename,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              subtitle: file.originalPath != null
                  ? Text(
                      '${file.originalPath!.display} → ${file.path.display}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    )
                  : file.path.parent.isEmpty
                  ? null
                  : Text(
                      file.path.parent,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
              selected: _selectedFile?.path == file.path,
              trailing:
                  gitPresentation(context).entryActionPlacement ==
                      GitEntryActionPlacement.contextMenu
                  ? null
                  : GitMenuButton(
                      role: GitMenuRole.entryContext,
                      host: session.host,
                      entries: entries,
                      onSelected: (value) => unawaited(action(value)),
                    ),
              onTap: activate,
            ),
          ),
        );
      },
    );
  }

  Widget _detailPane() =>
      widget.inspector ? _compactDetailPane() : _browserDetailPane();

  void _inspectorParent(GitCommit commit, GitOid parent, int generation) {
    if (!mounted ||
        !widget.active ||
        generation != _selectionGeneration ||
        _selected?.oid != commit.oid)
      return;
    widget.session.setViewState('inspectorFile', '');
    unawaited(_loadInspector(target: parent));
  }

  String _commitBody(GitCommit commit) {
    final message = commit.message.trimLeft();
    final paragraph = message.indexOf(RegExp(r'\r?\n\s*\r?\n'));
    if (paragraph >= 0 &&
        message
                .substring(0, paragraph)
                .replaceAll(RegExp(r'\s+'), ' ')
                .trim() ==
            commit.subject.trim()) {
      return message.substring(paragraph).trimLeft();
    }
    final line = message.indexOf('\n');
    if (line >= 0 &&
        message.substring(0, line).trimRight() == commit.subject.trimRight()) {
      return message.substring(line + 1).trimLeft();
    }
    return message.trimRight() == commit.subject.trimRight() ? '' : message;
  }

  Future<void> _commitDetails(GitCommit commit) =>
      widget.session.host.present<void>(
        context,
        GitMessages.commitDetails,
        GitCommitDetails(
          commit: commit,
          references: List.unmodifiable(
            _references.where((ref) => ref.oid == commit.oid),
          ),
        ),
      );

  Widget _compactDetailPane() {
    final commit = _selected!;
    final session = widget.session;
    final generation = _selectionGeneration;
    final body = _commitBody(commit);
    final references = _references
        .where((ref) => ref.oid == commit.oid)
        .toList();
    final differentIdentity =
        commit.committer.isNotEmpty &&
        (commit.committer != commit.author ||
            commit.committerEmail != commit.email);
    final differentDate =
        commit.committerDate != null && commit.committerDate != commit.date;
    final committerRows = (differentIdentity ? 1 : 0) + (differentDate ? 1 : 0);
    final authorDetails = gitString(
      context,
      GitMessages.authorArg0Arg1Arg2,
      values: {
        'arg0': commit.author,
        'arg1': commit.email,
        'arg2': commit.date.toIso8601String(),
      },
    );
    Widget line(
      String text, {
      String? tooltip,
      TextStyle? style,
      int maxLines = 1,
    }) => GitTooltip(
      message: tooltip ?? text,
      child: Text(
        text,
        style: style,
        maxLines: maxLines,
        overflow: TextOverflow.ellipsis,
      ),
    );
    return LayoutBuilder(
      builder: (context, bounds) {
        final rowHeight = session.host.rowHeight(context);
        // Reserve at least three native file rows. Exceptional metadata is available
        // in the explicit details surface, never in another permanent scroll pane.
        final budget = ((bounds.maxHeight / rowHeight).floor() - 3).clamp(
          4,
          10,
        );
        var remaining = budget - 4;
        final showCommitter = committerRows > 0 && remaining >= committerRows;
        if (showCommitter) remaining -= committerRows;
        final showReferences = references.isNotEmpty && remaining > 0;
        if (showReferences) remaining--;
        final bodyLines = body.isEmpty ? 0 : remaining.clamp(0, 3);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              key: PageStorageKey(
                'git-commit-information:${session.repository.key}:${commit.oid.value}',
              ),
              padding: gitPresentation(context).logContentInsets(context),
              child: GitSelectionArea(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    line(
                      '${gitString(context, GitMessages.author2)} · ${commit.author}',
                      tooltip: authorDetails,
                    ),
                    line(
                      gitPresentation(
                        context,
                      ).formatCommitDate(context, commit.date),
                      tooltip: authorDetails,
                      style: GitTheme.of(context).textTheme.bodySmall,
                    ),
                    if (showCommitter) ...[
                      if (differentIdentity)
                        line(
                          '${gitString(context, GitMessages.committer)} · ${commit.committer}',
                          tooltip: gitString(
                            context,
                            GitMessages.committerArg0Arg1Arg2,
                            values: {
                              'arg0': commit.committer,
                              'arg1': commit.committerEmail,
                              'arg2': commit.committerDate?.toIso8601String(),
                            },
                          ),
                        ),
                      if (commit.committerDate case final date?
                          when differentDate)
                        line(
                          '${differentIdentity ? '' : '${gitString(context, GitMessages.committer)} · '}${gitPresentation(context).formatCommitDate(context, date)}',
                          tooltip: date.toIso8601String(),
                          style: GitTheme.of(context).textTheme.bodySmall,
                        ),
                    ],
                    line(commit.oid.abbreviated, tooltip: commit.oid.value),
                    if (bodyLines > 0)
                      Padding(
                        padding: EdgeInsets.symmetric(
                          vertical: session.host.spacing,
                        ),
                        child: Text(
                          body,
                          key: const ValueKey('git-commit-body'),
                          maxLines: bodyLines,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    if (showReferences)
                      line(
                        references.map((ref) => ref.shortName).join(' · '),
                        tooltip: references.map((ref) => ref.name).join('\n'),
                        style: GitTheme.of(context).textTheme.bodySmall,
                      ),
                    if (commit.boundary)
                      const GitLabel(
                        GitMessages
                            .shallowPartialBoundaryAParentObjectIsUnavailable,
                      ),
                    if (commit.parents.isNotEmpty)
                      Align(
                        alignment: AlignmentDirectional.centerStart,
                        child: commit.parents.length == 1
                            ? GitActionRow(
                                dense: true,
                                key: const ValueKey('git-inspector-parent'),
                                contentPadding: EdgeInsets.zero,
                                onTap: () => _inspectorParent(
                                  commit,
                                  commit.parents.single,
                                  generation,
                                ),
                                title: GitLabel(
                                  GitMessages.parentArg0,
                                  style: GitTheme.of(
                                    context,
                                  ).textTheme.bodySmall,
                                  values: {
                                    'arg0': commit.parents.single.abbreviated,
                                  },
                                ),
                              )
                            : _GitParentMenuRow(
                                key: const ValueKey('git-inspector-parent'),
                                host: session.host,
                                tooltip: GitMessages.parents,
                                entries: [
                                  for (
                                    var i = 0;
                                    i < commit.parents.length;
                                    i++
                                  )
                                    GitMenuEntry(
                                      'compare:$i',
                                      gitString(
                                        context,
                                        GitMessages.compareParentArg0Arg1,
                                        values: {
                                          'arg0': i + 1,
                                          'arg1': commit.parents[i].abbreviated,
                                        },
                                      ),
                                      checked: _parent == commit.parents[i],
                                      radio: true,
                                      localize: false,
                                    ),
                                  for (
                                    var i = 0;
                                    i < commit.parents.length;
                                    i++
                                  )
                                    GitMenuEntry(
                                      'open:$i',
                                      gitString(
                                        context,
                                        GitMessages.parentArg0,
                                        values: {
                                          'arg0': commit.parents[i].abbreviated,
                                        },
                                      ),
                                      sectionStart: i == 0,
                                      localize: false,
                                    ),
                                ],
                                onSelected: (value) {
                                  if (!mounted ||
                                      generation != _selectionGeneration ||
                                      _selected?.oid != commit.oid)
                                    return;
                                  final index = int.parse(
                                    value.split(':').last,
                                  );
                                  if (value.startsWith('open:')) {
                                    _inspectorParent(
                                      commit,
                                      commit.parents[index],
                                      generation,
                                    );
                                  } else {
                                    session.setViewState('inspectorFile', '');
                                    unawaited(
                                      _select(
                                        commit,
                                        parent: commit.parents[index],
                                      ),
                                    );
                                  }
                                },
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Flexible(
                                      child: Text(
                                        gitString(
                                          context,
                                          GitMessages.compareParentArg0Arg1,
                                          values: {
                                            'arg0':
                                                commit.parents.indexOf(
                                                  _parent ??
                                                      commit.parents.first,
                                                ) +
                                                1,
                                            'arg1':
                                                (_parent ??
                                                        commit.parents.first)
                                                    .abbreviated,
                                          },
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    SizedBox(width: session.host.spacing),
                                    const GitIcon(GitGlyph.down, size: 16),
                                  ],
                                ),
                              ),
                      ),
                  ],
                ),
              ),
            ),
            Padding(
              key: const ValueKey('git-changed-files'),
              padding: gitPresentation(context).logContentInsets(context),
              child: Semantics(
                header: true,
                child: GitLabel(
                  GitMessages.groupCount,
                  values: {
                    'group': gitString(context, GitMessages.changedFiles),
                    'count': _files.length,
                  },
                ),
              ),
            ),
            Expanded(child: _changedFilesPane(commit)),
          ],
        );
      },
    );
  }

  Widget _browserDetailPane() {
    final commit = _selected;
    final generation = _selectionGeneration;
    if (commit == null)
      return const Center(child: GitLabel(GitMessages.selectACommit));
    return GitSplitter(
      axis: Axis.vertical,
      initial: .40,
      minimum: 90,
      minimumSecond: 100,
      value: widget.session.split('logInfoSplit', .40),
      onChanged: (value) => widget.session.setViewState('logInfoSplit', value),
      first: SingleChildScrollView(
        key: PageStorageKey(
          'git-commit-information:${widget.session.repository.key}:${commit.oid.value}',
        ),
        padding: EdgeInsets.all(widget.session.host.spacing),
        child: GitSelectionArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                commit.message,
                style: GitTheme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 12),
              Text(
                gitString(
                  context,
                  GitMessages.authorArg0Arg1Arg2,
                  values: {
                    'arg0': commit.author,
                    'arg1': commit.email,
                    'arg2': commit.date.toLocal(),
                  },
                ),
              ),
              Text(
                gitString(
                  context,
                  GitMessages.committerArg0Arg1Arg2,
                  values: {
                    'arg0': commit.committer,
                    'arg1': commit.committerEmail,
                    'arg2': commit.committerDate?.toLocal(),
                  },
                ),
              ),
              GitSelectableText(commit.oid.value),
              if (commit.boundary)
                const GitLabel(
                  GitMessages.shallowPartialBoundaryAParentObjectIsUnavailable,
                ),
              for (final parent in commit.parents)
                GitButton(
                  onPressed: () {
                    if (widget.inspector) {
                      widget.session.setViewState('inspectorFile', '');
                      unawaited(_loadInspector(target: parent));
                      return;
                    }
                    final target = _commits
                        .where((c) => c.oid == parent)
                        .firstOrNull;
                    if (target != null)
                      unawaited(_select(target));
                    else
                      widget.session.host.notify(
                        GitMessages.parentIsOutsideThisPageOrAShallowBoundary,
                      );
                  },
                  child: Text(
                    gitString(
                      context,
                      GitMessages.parentArg0,
                      values: {'arg0': parent.abbreviated},
                    ),
                  ),
                ),
              for (final ref in _references.where((r) => r.oid == commit.oid))
                Text(ref.name),
              if (!_selectionOnly)
                GitButton(
                  onPressed: () => unawaited(_menu(commit)),
                  child: const GitLabel(GitMessages.commitActions),
                ),
            ],
          ),
        ),
      ),
      second: Column(
        key: const ValueKey('git-changed-files'),
        children: [
          if (commit.parents.length > 1)
            GitChoice<GitOid>(
              value: _parent,
              isExpanded: true,
              items: [
                for (var i = 0; i < commit.parents.length; i++)
                  GitChoiceItem(
                    value: commit.parents[i],
                    child: Text(
                      gitString(
                        context,
                        GitMessages.compareParentArg0Arg1,
                        values: {
                          'arg0': i + 1,
                          'arg1': commit.parents[i].abbreviated,
                        },
                      ),
                    ),
                  ),
              ],
              onChanged: (parent) {
                if (mounted &&
                    generation == _selectionGeneration &&
                    parent != null) {
                  if (widget.inspector)
                    widget.session.setViewState('inspectorFile', '');
                  unawaited(_select(commit, parent: parent));
                }
              },
            ),
          Padding(
            padding: EdgeInsets.all(widget.session.host.spacing),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Semantics(
                container: true,
                header: true,
                child: const GitLabel(GitMessages.changedFiles),
              ),
            ),
          ),
          Expanded(child: _changedFilesPane(commit)),
        ],
      ),
    );
  }

  Widget _diffPreview({bool expanded = false}) {
    final file = _selectedFile!;
    final commit = _selected!;
    final parent = _parent;
    final files = List<GitChange>.unmodifiable(_files);
    final generation = _selectionGeneration;
    final session = widget.session;
    final index = files.indexOf(file);
    bool current() =>
        mounted &&
        widget.session == session &&
        _selectionGeneration == generation &&
        _selected?.oid == commit.oid &&
        _parent == parent &&
        _selectedFile == file;
    void selectFile(int next) {
      if (current()) setState(() => _selectedFile = files[next]);
    }

    return Column(
      children: [
        Row(
          children: [
            if (expanded)
              GitButton.icon(
                onPressed: () {
                  if (!current()) return;
                  setState(() => _expandedDiff = false);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (!current()) return;
                    final focus = _previewReturnFocus;
                    if (focus?.context != null && focus!.canRequestFocus) {
                      focus.requestFocus();
                    } else {
                      _tableFocus.requestFocus();
                    }
                  });
                },
                icon: const GitIcon(GitGlyph.back),
                label: const GitLabel(GitMessages.log),
              )
            else
              GitIconButton(
                tooltip: gitString(context, GitMessages.reviewDifference),
                onPressed: () {
                  if (!current()) return;
                  _previewReturnFocus = FocusManager.instance.primaryFocus;
                  setState(() => _expandedDiff = true);
                },
                icon: const GitIcon(GitGlyph.expand),
              ),
            Expanded(
              child: Text(
                '${file.originalPath == null ? file.path.display : '${file.originalPath!.display} → ${file.path.display}'} · '
                '${parent?.abbreviated ?? gitString(context, GitMessages.emptyTree)} → '
                '${commit.oid.abbreviated}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        Expanded(
          child: GitDiffView(
            key: _previewKey,
            session: widget.session,
            preview: !expanded,
            comparison: GitComparison(
              file.path,
              parent == null
                  ? const ContentVersion.absent()
                  : ContentVersion(ContentKind.commit, revision: parent),
              ContentVersion(ContentKind.commit, revision: commit.oid),
              leftPath: file.originalPath,
            ),
            onPreviousFile: index <= 0 ? null : () => selectFile(index - 1),
            onNextFile: index < 0 || index + 1 >= files.length
                ? null
                : () => selectFile(index + 1),
          ),
        ),
      ],
    );
  }

  Future<void> _menu(GitCommit? commit, {Offset? position}) async {
    if (!mounted ||
        !widget.active ||
        _presentationRoute?.isActive == false ||
        _selectionOnly)
      return;
    final session = widget.session;
    final epoch = _interactionEpoch;
    final generation = _generation;
    final historyRevision = _historyRevision;
    final onCommitAction = widget.onCommitAction;
    final action = await session.host.menu(
      context,
      commit?.subject ?? GitMessages.actions,
      [
        if (commit != null) ...[
          for (final action in [
            GitMessages.createBranch2,
            GitMessages.createTag,
            GitMessages.compareRevisions,
            GitMessages.openSnapshot,
            GitMessages.cherryPickOperation,
            GitMessages.revertCommit,
            GitMessages.interactiveRebaseAfterThisBoundary,
            GitMessages.resetCurrentBranch,
          ])
            GitMenuEntry(
              action,
              action,
              enabled:
                  const {
                    GitMessages.compareRevisions,
                    GitMessages.openSnapshot,
                  }.contains(action) ||
                  !session.running && session.canWriteMetadata,
              sectionStart: const {
                GitMessages.createBranch2,
                GitMessages.compareRevisions,
                GitMessages.cherryPickOperation,
                GitMessages.interactiveRebaseAfterThisBoundary,
                GitMessages.resetCurrentBranch,
              }.contains(action),
            ),
          const GitMenuEntry(
            'details',
            GitMessages.viewCommitDetails,
            sectionStart: true,
          ),
          const GitMenuEntry('copy', GitMessages.copyCommitHash),
          const GitMenuEntry('copyMessage', GitMessages.copyCommitMessage),
        ],
      ],
      position: position,
      localizeTitle: false,
    );
    if (!_ownsInteraction(session, epoch) ||
        generation != _generation ||
        historyRevision != _historyRevision)
      return;
    if (commit == null) return;
    if (action == 'details') {
      await _commitDetails(commit);
      return;
    }
    if (action == 'copy') {
      await Clipboard.setData(ClipboardData(text: commit.oid.value));
      return;
    }
    if (action == 'copyMessage') {
      await Clipboard.setData(ClipboardData(text: commit.message));
      return;
    }
    if (action != null) {
      if (onCommitAction != null) {
        onCommitAction(commit, action);
      } else {
        await GitWorkflowUi(context, session).commitAction(commit, action);
      }
    }
  }

  Future<void> _goto() async {
    if (!mounted || !widget.active || _presentationRoute?.isActive == false)
      return;
    final session = widget.session;
    final epoch = _interactionEpoch, request = ++_dialogRequest;
    final value = await gitTextInput(
      context,
      session,
      GitMessages.goToCommitReference2,
      explanation: GitMessages.enterACommitIDOrReferenceToRevealInLog,
    );
    if (value == null ||
        value.isEmpty ||
        !_ownsDialogRequest(session, epoch, request))
      return;
    await _navigate(value);
  }

  Future<void> _navigate(String value, {bool reload = false}) async {
    _dialogRequest++;
    final generation = ++_generation;
    _readCancellation?.cancel();
    final cancellation = _readCancellation = GitCancellation();
    final loaded = _commits.where((e) => e.oid.value == value).firstOrNull;
    if (!reload && loaded != null) {
      setState(() {
        _loading = false;
        _failure = null;
        _navigationOutsideFilters = false;
      });
      await _reveal(loaded);
      return;
    }
    setState(() {
      _loading = true;
      _failure = null;
      _navigationOutsideFilters = false;
    });
    try {
      // Resolve names and abbreviated IDs through Git, independently of view
      // filters. A filtered ancestor must never impersonate the requested tip.
      final page = await widget.session.client.history(
        widget.session.repository,
        filter: HistoryFilter(reference: value),
        limit: 1,
        cancellation: cancellation,
      );
      if (!mounted || generation != _generation) return;
      if (page.commits.isEmpty) {
        throw const GitException(
          GitErrorCode.unavailable,
          diagnostic: GitMessages.theRequestedRevisionIsUnavailable,
        );
      }
      final target = page.commits.first;
      final existing = _commits.where((e) => e.oid == target.oid).firstOrNull;
      if (!reload && existing != null) {
        setState(() => _loading = false);
        await _reveal(existing);
      } else if (_hasFilters && _navigationReference == null) {
        // Keep the current filtered table and selection. The user can choose
        // to reveal the resolved object without discarding the filter fields.
        setState(() {
          _loading = false;
          _pendingNavigation = target.oid;
          _navigationOutsideFilters = true;
          _failure = const GitException(
            GitErrorCode.invalidRequest,
            diagnostic: GitMessages
                .theRequestedRevisionIsOutsideTheCurrentFiltersResetFilters,
          );
        });
      } else {
        _navigationReference = target.oid.value;
        await _load(preserveNavigation: true, reveal: target.oid);
      }
    } on Object catch (error) {
      if (mounted && generation == _generation) {
        setState(() {
          _loading = false;
          _failure = error is GitException
              ? error
              : GitException(
                  GitErrorCode.disconnected,
                  diagnostic: sanitizeGitDiagnostic('$error'),
                );
        });
      }
    }
  }

  Future<void> _reveal(GitCommit target) async {
    final index = _commits.indexWhere((e) => e.oid == target.oid);
    if (index < 0) return;
    setState(() {
      _selectedIds
        ..clear()
        ..add(target.oid);
      _selectionAnchor = index;
    });
    final details = _select(target);
    final selection = _selectionGeneration;
    await details;
    if (!mounted || selection != _selectionGeneration || !widget.active) return;
    _tableFocus.requestFocus();
    if (_tableScroll.hasClients) {
      final start = index * widget.session.host.rowHeight(context);
      final position = _tableScroll.position;
      if (start >= position.pixels &&
          start + widget.session.host.rowHeight(context) <=
              position.pixels + position.viewportDimension)
        return;
      _tableScroll.jumpTo(
        start.clamp(0, _tableScroll.position.maxScrollExtent),
      );
    }
  }

  Future<void> _dates() async {
    if (!mounted || !widget.active || _presentationRoute?.isActive == false)
      return;
    final session = widget.session, epoch = _interactionEpoch;
    final request = ++_dialogRequest;
    final range = await session.host.presentation.dateRange(
      context,
      start: _since,
      end: _until?.subtract(const Duration(days: 1)),
    );
    if (_ownsDialogRequest(session, epoch, request) && range != null) {
      _since = range.$1;
      _until = range.$2.add(const Duration(days: 1));
      await _load();
    }
  }
}

final class _LogReferenceChoice {
  const _LogReferenceChoice(this.reference);
  final String? reference;
}

// The popup owns its controller until its route actually unmounts. It uses
// immutable reviewed data and never reads a retired Log State's context.
final class _LogBranchFilterDialog extends StatefulWidget {
  const _LogBranchFilterDialog({
    required this.session,
    required this.references,
    required this.selected,
    required this.initialSearch,
    required this.chooseOnly,
    required this.isCurrent,
    required this.referenceCurrent,
    required this.onFailure,
    required this.onSearchChanged,
    required this.refresh,
  });
  final GitSession session;
  final List<GitReference> references;
  final String? selected;
  final String initialSearch;
  final bool chooseOnly;
  final bool Function() isCurrent;
  final bool Function(GitReference) referenceCurrent;
  final ValueChanged<GitException> onFailure;
  final ValueChanged<String> onSearchChanged;
  final Future<void> Function() refresh;
  @override
  State<_LogBranchFilterDialog> createState() => _LogBranchFilterDialogState();
}

final class _LogBranchFilterDialogState extends State<_LogBranchFilterDialog> {
  late final _search = TextEditingController(text: widget.initialSearch);
  final _expanded = <String, bool>{};
  ModalRoute<dynamic>? _route;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _route = ModalRoute.of(context);
  }

  bool _current() =>
      mounted && (_route?.isActive ?? true) && widget.isCurrent();
  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _choose(String? reference) {
    if (!mounted) return;
    gitCompleteSurface(
      context,
      _current() ? _LogReferenceChoice(reference) : null,
    );
  }

  @override
  Widget build(BuildContext context) => _logBranches(
    context,
    search: _search,
    expanded: _expanded,
    onToggle: (group) {
      if (_current())
        setState(() => _expanded[group] = !(_expanded[group] ?? true));
    },
    references: widget.references,
    selected: widget.selected,
    onSearchChanged: () {
      if (!_current()) return;
      setState(() {});
      widget.onSearchChanged(_search.text);
    },
    onChoose: _choose,
    referenceBuilder: (ref, group) => _logBranchReference(
      context,
      session: widget.session,
      references: widget.references,
      ref: ref,
      group: group,
      selected: widget.selected,
      chooseOnly: widget.chooseOnly,
      isCurrent: () => _current() && widget.referenceCurrent(ref),
      onChoose: _choose,
      onFailure: widget.onFailure,
      refresh: () => _current() ? widget.refresh() : Future<void>.value(),
    ),
  );
}

Widget _logBranches(
  BuildContext context, {
  required TextEditingController search,
  Map<String, bool>? expanded,
  ValueChanged<String>? onToggle,
  required List<GitReference> references,
  required String? selected,
  required VoidCallback onSearchChanged,
  required ValueChanged<String?> onChoose,
  required Widget Function(GitReference, String) referenceBuilder,
}) {
  final filter = search.text.toLowerCase();
  return GitReferenceNavigation(
    builder: (results) => Column(
      children: [
        gitReferenceSearchNavigation(
          controller: search,
          results: results,
          child: GitTextField(
            controller: search,
            decoration: GitFieldDecoration(
              labelText: gitString(context, GitMessages.searchBranchesAndTags),
              prefixIcon: GitIcon(GitGlyph.search),
              isDense: true,
            ),
            onChanged: (_) => onSearchChanged(),
          ),
        ),
        SizedBox(height: GitHostScope.of(context)!.spacing),
        Expanded(
          child: gitReferenceResults(
            focus: results,
            child: ListView(
              children: [
                GitReferenceRow(
                  key: const ValueKey('git-all-references'),
                  title: gitString(context, GitMessages.allReferences),
                  selected: selected == null,
                  onTap: () => onChoose(null),
                ),
                for (final group in [
                  GitMessages.local,
                  GitMessages.remote,
                  GitMessages.tags,
                ])
                  GitReferenceRow(
                    key: ValueKey('git-reference-group-$group'),
                    title: gitString(context, group),
                    expanded: expanded?[group] ?? true,
                    onTap: onToggle == null ? null : () => onToggle(group),
                    onToggle: onToggle == null ? null : () => onToggle(group),
                    children: [
                      for (final ref in references.where(
                        (ref) =>
                            ref.name.startsWith(
                              group == GitMessages.local
                                  ? 'refs/heads/'
                                  : group == GitMessages.remote
                                  ? 'refs/remotes/'
                                  : 'refs/tags/',
                            ) &&
                            ref.shortName.toLowerCase().contains(filter),
                      ))
                        referenceBuilder(ref, group),
                    ],
                  ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}

Widget _logBranchReference(
  BuildContext context, {
  required GitSession session,
  required List<GitReference> references,
  required GitReference ref,
  required String group,
  required String? selected,
  required bool chooseOnly,
  required bool Function() isCurrent,
  required ValueChanged<String> onChoose,
  required ValueChanged<GitException> onFailure,
  required Future<void> Function() refresh,
}) {
  final actions = GitBranchActions(
    context,
    session,
    reviewed: session.snapshot,
    references: references,
    isCurrent: isCurrent,
    apply: (request) async {
      final outcome = await session.mutate(request);
      final failure = outcome?.error ?? session.failure;
      if (isCurrent() && failure != null) onFailure(failure);
      return outcome;
    },
    refresh: refresh,
  );
  Future<void> menu(Offset position) async {
    if (!isCurrent() || chooseOnly) return;
    final action = await session.host.menu(
      context,
      ref.shortName,
      actions.entries(ref),
      position: position,
      localizeTitle: false,
    );
    if (action != null && isCurrent()) await actions.act(ref, action);
  }

  return GitReferenceContextMenu(
    key: ValueKey(ref.name),
    open: chooseOnly ? null : menu,
    child: GitReferenceRow(
      depth: 1,
      onSecondaryTapUp: chooseOnly
          ? null
          : (details) => unawaited(menu(details.globalPosition)),
      leading: GitIcon(
        ref.current
            ? GitGlyph.check
            : group == GitMessages.tags
            ? GitGlyph.tag
            : GitGlyph.branch,
        size: 16,
      ),
      title: ref.shortName,
      selected: selected == ref.name,
      onTap: () => onChoose(ref.name),
    ),
  );
}

final class _GitParentMenuRow extends StatelessWidget {
  const _GitParentMenuRow({
    super.key,
    required this.host,
    required this.tooltip,
    required this.entries,
    required this.onSelected,
    required this.child,
  });
  final GitHost host;
  final String tooltip;
  final List<GitMenuEntry> entries;
  final ValueChanged<String> onSelected;
  final Widget child;
  @override
  Widget build(BuildContext context) => GitTooltip(
    message: gitString(context, tooltip),
    child: GitActionRow(
      dense: true,
      contentPadding: EdgeInsets.zero,
      title: DefaultTextStyle.merge(
        style: GitTheme.of(context).textTheme.bodySmall,
        child: child,
      ),
      onTap: () async {
        final value = await host.menu(context, tooltip, entries);
        if (context.mounted && value != null) onSelected(value);
      },
    ),
  );
}

final class GitGraphRow {
  const GitGraphRow(
    this.lane,
    this.width,
    this.edges, {
    this.unloaded = const {},
    this.boundary = false,
  });
  final int lane, width;
  final List<(int, int, bool)> edges;
  final Set<int> unloaded;
  final bool boundary;
}

/// Lane continuity is computed from actual full parent identities, retaining
/// pending parent lanes across page boundaries.
List<GitGraphRow> graphRows(List<GitCommit> commits) {
  final lanes = <GitOid>[], rows = <GitGraphRow>[];
  final loaded = commits.map((commit) => commit.oid).toSet();
  for (final commit in commits) {
    if (!lanes.contains(commit.oid)) lanes.add(commit.oid);
    final before = List<GitOid>.of(lanes), lane = lanes.indexOf(commit.oid);
    lanes.removeAt(lane);
    for (var i = 0; i < commit.parents.length; i++) {
      final parent = commit.parents[i];
      if (!lanes.contains(parent))
        lanes.insert(
          i == 0 ? lane.clamp(0, lanes.length) : lanes.length,
          parent,
        );
    }
    final edges = <(int, int, bool)>[];
    for (var i = 0; i < before.length; i++) {
      if (i != lane) edges.add((i, lanes.indexOf(before[i]), false));
    }
    for (final parent in commit.parents) {
      edges.add((lane, lanes.indexOf(parent), true));
    }
    rows.add(
      GitGraphRow(
        lane,
        before.length > lanes.length ? before.length : lanes.length,
        edges,
        unloaded: {
          for (final parent in commit.parents)
            if (!loaded.contains(parent)) lanes.indexOf(parent),
        },
        boundary: commit.boundary,
      ),
    );
  }
  return rows;
}

final class _GraphPainter extends CustomPainter {
  const _GraphPainter(this.row, this.color, {this.offset = 0});
  final GitGraphRow row;
  final Color color;
  final double offset;
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    double x(int lane) => lane * 14.0 + 10 - offset;
    for (final edge in row.edges) {
      final path = Path()
        ..moveTo(x(edge.$1), edge.$3 ? size.height / 2 : 0)
        ..lineTo(x(edge.$1), size.height / 2)
        ..cubicTo(
          x(edge.$1),
          size.height * .75,
          x(edge.$2),
          size.height * .75,
          x(edge.$2),
          size.height * .9,
        )
        ..lineTo(x(edge.$2), size.height);
      canvas.drawPath(path, paint);
      if (edge.$3 && row.unloaded.contains(edge.$2)) {
        canvas.drawPath(
          Path()
            ..moveTo(x(edge.$2) - 3, size.height - 5)
            ..lineTo(x(edge.$2), size.height - 1)
            ..lineTo(x(edge.$2) + 3, size.height - 5),
          paint,
        );
      }
    }
    canvas.drawLine(
      Offset(x(row.lane), 0),
      Offset(x(row.lane), size.height / 2),
      paint,
    );
    canvas.drawCircle(
      Offset(x(row.lane), size.height / 2),
      3.5,
      paint..style = row.boundary ? PaintingStyle.stroke : PaintingStyle.fill,
    );
  }

  @override
  bool shouldRepaint(covariant _GraphPainter oldDelegate) =>
      oldDelegate.row != row ||
      oldDelegate.color != color ||
      oldDelegate.offset != offset;
}
