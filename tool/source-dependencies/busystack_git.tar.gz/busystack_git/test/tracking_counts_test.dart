import 'dart:convert';
import 'package:busystack_git/busystack_git.dart';
import 'package:busystack_git/src/parsers.dart';
import 'package:test/test.dart';
import 'support/repository_fixture.dart';

void main() {
  test(
    'omitted branch.ab differs from a measured zero and survives typed handoff',
    () {
      for (final ab in [null, '+0 -0', '+2 -3']) {
        final parsed = parseStatusV2(
          utf8.encode(
            '# branch.upstream origin/main\u0000'
            '${ab == null ? '' : '# branch.ab $ab\u0000'}',
          ),
        );
        expect(parsed.trackingCountsKnown, ab != null);
        final snapshot = GitSnapshot(
          repository: const RepositoryId(
            root: '/r',
            gitDir: '/r/.git',
            commonDir: '/r/.git',
            objectFormat: 'sha1',
          ),
          token: 't',
          indexToken: 'i',
          changes: const [],
          operation: const RepositoryOperation(GitOperationKind.none),
          observedAt: DateTime.utc(2026),
          upstream: parsed.upstream,
          ahead: parsed.ahead,
          behind: parsed.behind,
          trackingCountsKnown: parsed.trackingCountsKnown,
        );
        expect(
          GitSnapshot.fromJson(snapshot.toJson()).trackingCountsKnown,
          ab != null,
        );
        final oldPacket = snapshot.toJson()..remove('trackingCountsKnown');
        expect(GitSnapshot.fromJson(oldPacket).trackingCountsKnown, isFalse);
      }
    },
  );
  test(
    'missing upstream object is unknown, present tracking ref reports real counts',
    () async {
      final f = await RepositoryFixture.create();
      addTearDown(f.close);
      await f.commit('a.md', utf8.encode('base'), 'base');
      final tip = await f.git(['rev-parse', 'HEAD']);
      await f.git([
        'config',
        'remote.origin.url',
        '${f.directory.path}/unused',
      ]);
      await f.git([
        'config',
        'remote.origin.fetch',
        '+refs/heads/*:refs/remotes/origin/*',
      ]);
      await f.git(['config', 'branch.main.remote', 'origin']);
      await f.git(['config', 'branch.main.merge', 'refs/heads/main']);
      final missing = await f.engine.status(f.repository);
      expect(missing.upstream, 'origin/main');
      expect(missing.trackingCountsKnown, isFalse);
      await f.git(['update-ref', 'refs/remotes/origin/main', tip]);
      final equal = await f.engine.status(f.repository);
      expect(equal.trackingCountsKnown, isTrue);
      expect(equal.ahead, 0);
      expect(equal.behind, 0);
      await f.commit('a.md', utf8.encode('next'), 'next');
      final ahead = await f.engine.status(f.repository);
      expect(ahead.trackingCountsKnown, isTrue);
      expect(ahead.ahead, 1);
      expect(ahead.behind, 0);
      await f.git(['checkout', '--detach', 'HEAD']);
      final detached = await f.engine.status(f.repository);
      expect(detached.upstream, isNull);
      expect(detached.trackingCountsKnown, isFalse);
    },
  );
}
